import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { RegisterComponent } from '../register/register.component';
import { LoginComponent } from '../login/login.component';
import { HomeComponent } from '../home/home.component';
import { SecurityGuard } from '../security.guard';
import { CartComponent } from '../home/cart/cart.component';
import { OfferComponent } from '../home/offer/offer.component';
import { PaymentComponent } from '../home/payment/payment.component';

let routes:Routes= 
[
        { path:"register" ,component:RegisterComponent },
        { path:"login" ,component:LoginComponent },
        { path:"home" ,component:HomeComponent ,canActivate:[SecurityGuard] ,
                children:[ 
                        { path:"cart" ,component:CartComponent },
                        { path:"offers" ,component:OfferComponent },
                        { path:"payment" ,component:PaymentComponent }
                        ]
},
        { path:"**",redirectTo:"login"}
]
@NgModule({
  declarations: [],
  imports: [
    CommonModule,RouterModule.forRoot(routes),
  ],
  exports:[RouterModule]
})
export class CarRoutingModule { }
