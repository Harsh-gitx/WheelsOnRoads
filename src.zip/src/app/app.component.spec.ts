import { TestBed, async } from '@angular/core/testing';
import { AppComponent } from './app.component';

describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppComponent
      ],
    }).compileComponents();
  }));

  // it('should create the app', () => {
  //   const fixture = TestBed.createComponent(AppComponent);
  //   const app = fixture.debugElement.componentInstance;
  //   expect(app).toBeTruthy();
  // });

  // it(`should have as title 'HW'`, () => {
  //   const fixture = TestBed.createComponent(AppComponent);
  //   const app = fixture.debugElement.componentInstance;
  //   expect(app.title).toEqual('HW');
  // });

  // it('should render title in a h1 tag', () => {
  //   const fixture = TestBed.createComponent(AppComponent);
  //   fixture.detectChanges();
  //   const compiled = fixture.debugElement.nativeElement;
  //   expect(compiled.querySelector('h1').textContent).toContain('Welcome to HW!');
  // });






  it("firstComponentTest",()=>{
    let component=TestBed.createComponent(AppComponent)
    console.log(component)
    let appComponent=component.componentInstance;
     expect(appComponent.title).toBeTruthy()    
  })

  
  it("firstComponent",()=>{
    let component=TestBed.createComponent(AppComponent)
    console.log(component)
    let appComponent=component.componentInstance;
     expect(appComponent.title).toBe("HW")   
  })
  

  it("testTemplate",()=>{
    let component=TestBed.createComponent(AppComponent)
    component.detectChanges();
    let HTMLTitle=component.nativeElement;
    console.log(HTMLTitle)
    let compTitle=component.componentInstance.title;
    expect(HTMLTitle.querySelector('h1').textContent).toContain(compTitle)

  })
  
  it("testFood",()=>{
    let component=TestBed.createComponent(AppComponent)
    component.detectChanges();
    let HTMLTitle=component.nativeElement;
    console.log(HTMLTitle)
    let compFood=component.componentInstance.food;
    expect(HTMLTitle.querySelector('span').textContent).toEqual(compFood);

  })
  
  
  it("testName",()=>{
    let component=TestBed.createComponent(AppComponent)
    component.detectChanges();
    let name=component.componentInstance.name;
    expect(name).toBeUndefined()
  })















});
