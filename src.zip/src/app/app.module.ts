import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { LoginModule } from './login/login.module';
import { HomeModule } from './home/home.module';
import { RegisterModule } from './register/register.module';
import { SecurityGuard } from './security.guard';
import { CartComponent } from './home/cart/cart.component';
import { OfferComponent } from './home/offer/offer.component';
import { PaymentComponent } from './home/payment/payment.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CarRoutingModule } from './car-routing/car-routing.module';


@NgModule({ 
 declarations:[AppComponent],
 imports:[BrowserModule , 
    LoginModule,HomeModule,RegisterModule, BrowserAnimationsModule,CarRoutingModule],
 providers:[],
 bootstrap:[AppComponent]
})
export class AppModule { }

