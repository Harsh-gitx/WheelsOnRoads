import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, Validators } from '@angular/forms';
import { customValidator } from './Validation';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  userDetails={name:"chintan",password:"chintan",email:"chaintan@gmail.com"}
  constructor(private router:Router,private builder:FormBuilder) { }
  regForm
  submit(){
    let userString=JSON.stringify(this.userDetails)
    localStorage.setItem(this.userDetails.email,userString)
    this.router.navigate(["/login"])
    //get Data using localStorage
    //console.log(localStorage.getItem("user"))

  }


  

  ngOnInit() {
  this.regForm=this.builder.group(
    {
    password:['',Validators.required],
    confirmPass:['',Validators.required]
    },{validator:customValidator}
  )



    // u guys ignore this
    //this.submit()
  }
}
