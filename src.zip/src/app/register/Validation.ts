import { FormGroup } from "@angular/forms";

export function customValidator(group:FormGroup){
    //console.log("inside custom V")
    let password=group.value.password
    let confirmPassword=group.value.confirmPass
    //console.log(password)
    //console.log(confirmPassword)
    if(password==confirmPassword)
    return null
    else 
        return { 'custom':true }
}