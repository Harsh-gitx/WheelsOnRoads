import { Component, OnInit } from '@angular/core';
import { OfferService } from '../offer.service';
import { CartService } from '../cart/cart.service';

@Component({
  selector: 'app-offer',
  templateUrl: './offer.component.html',
  styleUrls: ['./offer.component.css']
})
export class OfferComponent implements OnInit {
  carData
  constructor(private _service:OfferService,private cart:CartService) { }

  ngOnInit() {
    this._service.getData().subscribe(data=>
        {
          this.carData=data['result'][1].cars;
          this.carData.forEach(car=>car.price=1500)
        }
      )
  }
  count
  //adding cars to cart
  addToCart(car){
    console.log(car)

    let index=this.cart.cartItems
    .findIndex(cartCar=>cartCar.name==car.name)
    if(index==-1)
      {
        this.cart.cartItems.push(car)
        this.count=this.cart.cartItems.length
        console.log(this.cart.cartItems)
    }
    else{
      alert("car is already present in the cart")
    }
  }

}
