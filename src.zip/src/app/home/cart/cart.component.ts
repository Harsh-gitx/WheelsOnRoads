import { Component, OnInit } from '@angular/core';
import { CartService } from './cart.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cart=[]
  total=0
    constructor(private _service:CartService,private router:Router) {
      this.cart=_service.cartItems
  }
  

  remove(carName){
    //step 1 find the index
  let index=this.cart.findIndex( car=> car.name==carName  )

  //step 2 use splice
this.cart.splice(index,1)
this.calculateTotal()
      }


      calculateTotal(){
        this.total=0;
        this.cart.forEach(car => this.total=this.total+car.price);
      }

      navigateToPayment(){
        this.router.navigate(["home/payment"])
      }


  ngOnInit() {
    this.calculateTotal()
  }

}
