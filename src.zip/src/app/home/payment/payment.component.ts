import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
  enteredCaptcha
  showError
  constructor() { }

  validateCaptcha(){
    if(this.enteredCaptcha==this.captcha){
      this.showError=false
      alert("payment success")
    }
    else{
      this.showError=true
      this.refreshCaptcha()
    }
  }

  generateCaptcha(){
    let alphabets=["a","b","c","d","e","f","g","h","i","j","k","l"
  ,"m","n","o","p","q","r","s","t","u","v","w","x","y","z" ]
   let num=""
    for(let i=0;i<6;i++){
      num=num+Math.floor(Math.random()*10)
    }
    return ""+num[0]+num[1]+alphabets[num[2]]+
    num[3]+alphabets[num[4]]+alphabets[num[5]]+""
  }
captcha

refreshCaptcha(){
  this.captcha=this.generateCaptcha()
}

  ngOnInit() {
    this.captcha=this.generateCaptcha()
  }

}
