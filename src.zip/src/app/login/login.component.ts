import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  showError=false

  constructor(private router:Router,private _http:HttpClient) { }

  gotToRegister(){
    //navigate to register
    this.router.navigate(["/register"])
  }
  //Assume that it is coming from Form
  userDetails={ email:"chaintan@gmail.com",password:"chintan"}

  login(){
    let userString=localStorage.getItem(this.userDetails.email)
    if(userString!=null)
    {
      let userObj=JSON.parse(userString)
    //authentication logic
    if(userObj.email==this.userDetails.email && userObj.password==this.userDetails.password){

      //setting the session storage for security gaurd
      sessionStorage.setItem("user",this.userDetails.email)

      this.router.navigate(["/home/offers"])
    }else{
      this.showError=true
    }
  }
  else{
    this.showError=true
  }

  }

  ngOnInit() {
    let user=sessionStorage.getItem("user")
    if(user!=null){
      this.router.navigate(["/home/offers"])
    }
    // this._http.get("https://api.zoomcar.com/v4/search?lat=12.9981732&lng=77.55304460000002&starts=2019-10-12%2017%3A00&ends=2019-10-12%2023%3A00&type=zoom_later&bracket=with_fuel&platform=web&version=2&device_id=000&device_name=000&city=bangalore&zap=true")
    // .subscribe(data=>console.log(data))
  }

}
